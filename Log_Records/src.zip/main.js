let obj = require("./logRecords");
obj.readRecords();
obj.storeRecords();
