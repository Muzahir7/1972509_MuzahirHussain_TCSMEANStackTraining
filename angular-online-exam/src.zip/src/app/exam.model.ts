export class Exam {
    constructor(public id:number, public question:string, public op1:string, public op2:string, public op3:string, public op4:string, public ans:string){}
}