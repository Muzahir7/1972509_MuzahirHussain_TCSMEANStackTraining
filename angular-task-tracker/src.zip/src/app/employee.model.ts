export class Employee {
    constructor(public id:any, public name:any, public task:any, public deadline:any){}
}